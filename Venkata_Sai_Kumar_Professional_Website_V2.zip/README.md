# Venkata Sai Kumar — Professional Portfolio v2

This website was built from the uploaded professional profile. It includes the career history, responsibilities, skills, education and certifications contained in that profile.

## Publish free with GitHub Pages
1. Create a GitHub account and a new public repository.
2. Upload `index.html` and `style.css`.
3. Open Settings → Pages.
4. Select Deploy from branch → `main` → `/root`.
5. Save and open the generated GitHub Pages address.

## Notes
- Contact details in this version come directly from the supplied profile.
- Review the exact career dates/titles before public publishing if your current CV has changed.
- Add a LinkedIn URL and optional professional photo when ready.
